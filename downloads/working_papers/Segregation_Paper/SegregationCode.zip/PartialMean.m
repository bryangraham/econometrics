function [pm_hat, se_pm_hat] = PartialMean(Y,S,s,R,tau,G,h,KernelType)

% OVERVIEW

% This function estimates a partial mean as described by Newey (1994, ET).
% It allows for "clustered" data and computes standard errors using a
% "fixed-h" GMM type approximation.

% INPUTS:
% Y             : N x 1 vector of individual outcome variables
% S             : N x 1 vector of variable to be held fix
% s             : P x 1 vector of evaluate points for partial mean
% R             : N x L vector of variables to be averaged over
% tau           : N x 1 vector of trimming indicators
% G             : N x 1 vector of group indicators (for the C groups) 
% h             : 2 x 1 vector of scalar bandwidth value used for kernel estimates
%                 h = (h1,h2)' with h1 used for m(s,r) & f(s,r), h2 used
%                 for dm(s,r)/ds & df(s,r)/ds
% KernelType    : Radially symmetric kernal if 1 and standard multivariate normal kernel
%                 otherwise

% OUTPUTS:
% pm_hat     : partial mean estimate
% se_pm_hat  : estimated asymptotic standard error of partial mean estimate

[N K] = size([S R]);    % Number of observations and regressors
ID  = unique(G);        % Vector group ID variables
C   = length(ID);       % Total number of groups

% STEP 1 : If user does not supply bandwidth parameter then use
%          the multivariate density version of Silvermans`'s (1986) 
%          'rule-of-thumb' as described on pp. 86 - 87 of his *Density
%          Estimation* book. This bandwidth is optimal for estimation of a
%          density which is multivariate standard normal. To get the second
%          bandwidth value we rescale to be of the order appropriate for pointwise
%          derivative estimation.

% Choose bandwidth parameter(s) if not supplied by the user
if isempty(h)==1    
    if KernelType == 1
        % Bandwidth for radially symmetric Epanechnikov kernel
        v_d          = (2*pi^(K/2))/(K*gamma(K/2));    % volume of K-dimensional sphere
        A            = ((8*K*(K+2)*(K+4)*(2/sqrt(pi))^K)/((2*K+1)*v_d))^(1/(K+2));
    else
        % Bandwidth for standard multivariate normal kernel
        % (cf., Wand and Jones, 1995, p. 111)
        A            = (4/(K + 2))^(1/(K+4));
    end
    h1           = A*C^(-1/(K+4));                 % 'rule-of-thumb' bandwidth
    h2           = h1*C^(1/(K+4) - 1/(K+4+2));     % rescale 'rule-of-thumb' bandwidth           
else
    h1 = h(1);
    h2 = h(2);
end

% STEP 2 : Compute pm_hat and its asymptotic
%          variance for each of the P evaluation points

P           = length(s);                                    % number of evaluation points
pm_hat      = zeros(P,1);
se_pm_hat   = zeros(P,1);

for p = 1:P
    p
    s_p = repmat(s(p),N,1);     
    
    % compute m(s,r)=E[Y|S=s,R=r] and partial mean at s(p)
    k_sr        = K_h([S R],[s_p R],[h1; h2],0,KernelType);  % N x P
    alpha2      = mean(repmat(Y,1,N) .* k_sr);               % 1 x P  (NOTE: P = N in this case)
    alpha1      = mean(k_sr);                                % 1 x P    
    m           = (alpha2 ./ alpha1)';                       % P x 1    
    pm_hat(p)   = sum(tau .* m)/sum(tau);                    % trimmed partial mean estimate      
    
    % compute joint density of S,R 
    f_sr        = mean(k_sr);                                % 1 x P vector density estimates
    
    % compute "moments" and their inverse Jacobian
    % NOTE: we are, in effect, doing fixed bandwidth GMM-style asymptotics
    iGAMMA = C*[-diag((N*f_sr).^-1) zeros(N,1); -(tau' .* (N*f_sr).^-1)/sum(tau) 1/sum(tau)];   % N + 1 x N + 1 Jacobian
    mom    =   [k_sr .* (repmat(Y,1,N) - repmat(m',N,1)) tau .* (pm_hat(p) - m)]';              % N + 1 x N matrix of moments     
    
    clear k_sr alpha1 alpha2 m f_sr;
    
    % compute covariance of moments taking into account within-group
    % dependence
    OMEGA = zeros(N+1,N+1);
    for c=1:C
        i_c = find(G==ID(c));
        mom_c = sum(mom(:,i_c),2);              
        OMEGA = OMEGA + mom_c*mom_c'/C;
    end
    
    V_hat = iGAMMA*OMEGA*iGAMMA';
    se_pm_hat(p)        =  sqrt(V_hat(N+1,N+1)/C);
    clear iGAMMA mom OMEGA V_hat;
end