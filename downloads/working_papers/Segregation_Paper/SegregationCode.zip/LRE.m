 function [theta_hat] = LRE(Y,T,S,R,G,trim,h,h_grid,KernelType,UnderSmoothingFactor)

% OVERVIEW

% This function estimates the LRE estimands using the semiparametric
% M-estimators described in Graham, Imbens and Ridder (2009). In particular
% theta_hat includes the average spillover effect, the local segregation
% outcome effect, the local private peer effect, the local external peer
% effect and the local segregation inequality effect.

% INPUTS:
% Y             : N x 1 vector of individual outcome variables
% T             : N x 1 vector of individual types
% S             : N x 1 vector of fraction high types
% R             : N x L vector of group-level controls
% G             : N x 1 vector of group indicators (for the C groups) 
% trim          : N x 1 vector of trimming indicators (d(S) in the notation
%                 of the paper)
% h             : 6 x 1 vector of scalar bandwidth value used for kernel estimates
%                 h = (h1,h2,h3,h4,h5,h6)' with 
%                       h1 used for m_H(s,r)
%                       h2 used for dm_H(s,r)/ds
%                       h3 used for m_L(s,r)
%                       h4 used for dm_L(s,r)/ds 
%                       h5 used for f(s,n)
%                       h6 used for df(s,r)/ds
% h_grid        : bandwidth grid for cross-validation exercise
% KernelType    : Radially symmetric kernal if 1 and standard multivariate normal kernel
%                 otherwise
% UnderSmoothingFactor : Amount of additional undersmoothing

% OUTPUTS:
% theta_hat     : 
[N K] = size([S R]);
i = find(T==1);
N_H = length(i);
j = find(T==0);
N_L = length(j);


% STEP 1 : If user does not supply bandwidth parameter then use
%          the multivariate density version of Silvermans`'s (1986) 
%          'rule-of-thumb' as described on pp. 86 - 87 of his *Density
%          Estimation* book. This bandwidth is optimal for estimation of a
%          density which is multivariate standard normal. This value is
%          then rescaled to be of the order appropriate for pointwise
%          derivative estimation (as appropriate).


% Choose bandwidth parameter(s) if needed
if isempty(h)==1
    % PART A: Choose bandwidths for m_H(s,r) and dm_H(s,r)/ds by leave-own-group-out
    % cross validation
    Q           = length(h_grid);
    CV_Results  = [h_grid zeros(Q,1)];
    for q = 1:Q
        CV_Results(q,2) = LeaveGroupOutEPE(h_grid(q),Y(i),[S(i) R(i,:)],G(i),KernelType);
    end
    CV_Results = sortrows(CV_Results,2);
    h1 = CV_Results(1,1); 
    h2 = h1*N_H^(1/(K+4) - 1/(K+4+2)); 
    
    % PART B: Choose bandwidths for m_L(s,r) and dm_L(s,r)/ds by leave-own-group-out
    % cross validation
    CV_Results  = [h_grid zeros(Q,1)];
    for q = 1:Q
        CV_Results(q,2) = LeaveGroupOutEPE(h_grid(q),Y(j),[S(j) R(j,:)],G(j),KernelType);
    end
    CV_Results = sortrows(CV_Results,2);
    h3 = CV_Results(1,1); 
    h4 = h3*N_L^(1/(K+4) - 1/(K+4+2)); 
    
    % PART C: Choosen bandwidth for density estimates and derivative
    if KernelType == 1
        % Bandwidth for radially symmetric Epanechnikov kernel
        v_d          = (2*pi^(K/2))/(K*gamma(K/2));      % volume of K-dimensional sphere
        A            = ((8*K*(K+2)*(K+4)*(2/sqrt(pi))^K)/((2*K+1)*v_d))^(1/(K+2));
    else
        % Bandwidth for standard multivariate normal kernel
        % (cf., Wand and Jones, 1995, p. 111)
        A            = (4/(K + 2))^(1/(K+4));                
    end
    h5           = A*N^(-1/(K+4));                   % 'rule-of-thumb' bandwidth
    h6           = h5*N^(1/(K+4) - 1/(K+4+2));       % rescale 'rule-of-thumb' bandwidth   
    clear A v_d CV_Results Q;
else
    h1 = h(1);
    h2 = h(2);
    h3 = h(3); 
    h4 = h(4);
    h5 = h(5); 
    h6 = h(6);
end

% Now implement requested amount of undersmoothing
h1 = UnderSmoothingFactor*h1;
h2 = UnderSmoothingFactor*h2;
h3 = UnderSmoothingFactor*h3;
h4 = UnderSmoothingFactor*h4;
h5 = UnderSmoothingFactor*h5;
h6 = UnderSmoothingFactor*h6;

disp('Selected bandwidth values');
disp([h1 h2 h3 h4 h5 h6])

% STEP 2 : Compute various components of estimands and their influence
%          functions

% Estimate m_H(s,r)=E[Y|T=1,S=s,R=r] and its derivative w.r.t. s
[m_H, Ds_m_H] = KernelCEFAndGradient(Y(i),[S(i) R(i,:)],[S R],[h1; h2],1,KernelType);
Ds_m_H        = Ds_m_H(:,1);

% Estimate m_L(s,r)=E[Y|T=0,S=s,R=r] and its derivative w.r.t. s
[m_L, Ds_m_L] = KernelCEFAndGradient(Y(j),[S(j) R(j,:)],[S R],[h3; h4],1,KernelType);
Ds_m_L        = Ds_m_L(:,1);

% Estimate derivative of E[Y|S=s,R=r] with respect to s
p_sr = m_H - m_L;                               % p(s,r)
e_sr = S .* Ds_m_H + (1-S) .* Ds_m_L;           % e(s,r)
Ds_m = p_sr + e_sr;

% Estimate m
m = S .* m_H + (1-S) .* m_L;

% Estimate joint density of S,R & its derivative w.r.t. s
[f_sr, Ds_f_sr]    = K_h([S R],[S R],[h5; h6],1,KernelType);
f_sr               = mean(f_sr)';
Ds_f_sr            = mean(Ds_f_sr(:,1:N))';

% Estimate p_H (trimmed)
p_H = sum(trim .* T)/sum(trim);

% Estimate E[d(s,r)*dm(s,r)/ds]
E_Ds_m = sum(trim .* Ds_m)/sum(trim);

% Estimate E[d(s,r)*p(s,r)]
E_p = sum(trim .* p_sr)/sum(trim);

% Estimate E[d(s,r)*e(s,r)]
E_e = sum(trim .* e_sr)/sum(trim);

% STEP 3 : Estimate ASE, LSOE, LPPE, LEPE & LSIE by method-of-moments
ASE_hat            = mean(trim .* e_sr);
LSOE_hat           = mean(trim .* Ds_m .* (S - p_H));
LPPE_hat           = mean(trim .* p_sr .* (S - p_H));
LEPE_hat           = mean(e_sr .* (S - p_H));
LSIE_hat           = mean((1/p_H)*(m_H + S .* Ds_m_H) .* (S - p_H) - (1/(1-p_H))*(-m_L + (1-S) .* Ds_m_L) .* (S - p_H));

% STEP 4 : Estimate asymptotic standard errors
% Calculate correction terms associated with nonparametric first step
delta_ASE           = -(Ds_f_sr ./ f_sr) .* (Y - m) - (((T .* Y) ./ S - ((1-T) .* Y) ./ (1-S)) - p_sr);
delta_LSOE          = -(Ds_f_sr ./ f_sr) .* (Y - m) .* (S - p_H)...
                      -(Y - m) - E_Ds_m .* (T - p_H);
delta_LPPE          = (((T .* Y) ./ S - m_H) .* (S - p_H)) - ((((1-T) .* Y) ./ (1-S) - m_L) .* (S - p_H))...
                      - E_p .* (T - p_H);
delta_LEPE          = -(Ds_f_sr ./ f_sr) .* (Y - m) .* (S - p_H) - (Y - m)...
                      -(((T .* Y) ./ S - m_H) .* (S - p_H)) + ((((1-T) .* Y) ./ (1-S) - m_L) .* (S - p_H))...
                      -E_e .* (T - p_H);
delta_LSIE          = -(1/p_H)*(Ds_f_sr ./ f_sr) .* (T .* Y - S .* m_H) .* (S - p_H) - (1/p_H)*(T .* Y - S .* m_H)... 
                      -mean((1/p_H^2)*(S - p_H) .* m_H + (S.^2 / p_H^2) .* Ds_m_H) .* (T - p_H)...
                      +(1/(1-p_H))*(Ds_f_sr ./ f_sr) .* ((1-T) .* Y - (1-S) .* m_L) .* (S - p_H) + (1/(1-p_H))*((1-T) .* Y - (1-S) .* m_L)... 
                      +mean((1/(1-p_H)^2)*(S - p_H) .* m_L + ((1-S).^2 / (1-p_H)^2) .* Ds_m_L) .* (T - p_H);
% Moment functions evaluated at gamma_hat                   
psi_ASE               =  e_sr - ASE_hat;
psi_LSOE              =  Ds_m .* (S - p_H) - LSOE_hat;
psi_LPPE              =  p_sr .* (S - p_H) - LPPE_hat;
psi_LEPE              =  e_sr .* (S - p_H) - LEPE_hat;
psi_LSIE              =  (1/p_H)*(m_H + S .* Ds_m_H) .* (S - p_H) - (1/(1-p_H))*(-m_L + (1-S) .* Ds_m_L) .* (S - p_H) - LSIE_hat;

% Asymptotic standard error of gamma_hat
ID  = unique(G);
C   = length(ID); 
theta_hat = [ASE_hat LSOE_hat LPPE_hat LEPE_hat LSIE_hat; zeros(1,5)];

for c=1:C
    i_c = find(G==ID(c));
    phi_ASE_c  = sum(trim(i_c) .* (psi_ASE(i_c) + delta_ASE(i_c)));
    phi_LSOE_c = sum(trim(i_c) .* (psi_LSOE(i_c) + delta_LSOE(i_c)));
    phi_LPPE_c = sum(trim(i_c) .* (psi_LPPE(i_c) + delta_LPPE(i_c)));
    phi_LEPE_c = sum(trim(i_c) .* (psi_LEPE(i_c) + delta_LEPE(i_c)));
    phi_LSIE_c = sum(trim(i_c) .* (psi_LSIE(i_c) + delta_LSIE(i_c)));
    theta_hat(2,1) = theta_hat(2,1) + (phi_ASE_c.^2)/C;
    theta_hat(2,2) = theta_hat(2,2) + (phi_LSOE_c.^2)/C;
    theta_hat(2,3) = theta_hat(2,3) + (phi_LPPE_c.^2)/C;
    theta_hat(2,4) = theta_hat(2,4) + (phi_LEPE_c.^2)/C;
    theta_hat(2,5) = theta_hat(2,5) + (phi_LSIE_c.^2)/C;
end

theta_hat(2,:)     =  (((C/N)*theta_hat(2,:)*(C/N))/C).^(1/2);

disp('ASE LSOE LPPE LEPE LSIE');
disp(theta_hat);