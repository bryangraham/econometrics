function [EPE] = LeaveGroupOutEPE(h,Y,X,G,KernelType)

% OVERVIEW
% This function calculates mean squared prediction error for the
% leave-own-out kernel estimator of E[Y|X]. This criterion can be used for
% bandwidth selection. It allows for "clustered" data in that it performs a
% leave-own-cluster out variant of cross validation.

% INPUTS
% h     : Bandwidth value at which prediction error is being evaluated
% Y     : N x 1 vector of dependent variable realizations
% X     : N x K matrix of independent variable realizations
% G     : N x 1 vector of group assignment indicators

% OUTPUTS
% EPE   : mean squared prediction error for leave-own-group-out kernel estimator
%         of the CEF

[N K] = size(X);                    % Number of observations and regressors
ID  = unique(G);                    % Vector group ID variables
C   = length(ID);                   % Total number of groups
LeaveOwnGroupOutYHAT = zeros(N,1);  % Preallocate leave-own-out YHAT vector

% Calculate leave-own-out estimate of CEF for each X(i)
K_h_evals = K_h(X,X,[h; h],[],KernelType);          % N x N kernel evalautions
num       = repmat(Y,1,N) .* K_h_evals;             % N x N "numerator" elements
den       = K_h_evals;                              % N x N "denominator" elements
clear K_h_evals;

for c = 1:C
    j_c = find(G~=ID(c));
    i_c = find(G==ID(c));
    alpha2_c    = sum(num(j_c,i_c));                 % leave cth group out numerators
    alpha1_c    = sum(den(j_c,i_c));                 % leave cth group out denominators
    LeaveOwnGroupOutYHAT(i_c) = (alpha2_c ./ alpha1_c)';    
end

% Compute estimated mean squared prediction error
EPE = mean((Y - LeaveOwnGroupOutYHAT).^2);


