function [EPE] = LeaveOwnOutEPE(h,Y,X,KernelType)

% OVERVIEW
% This function calculates mean squared prediction error for the
% leave-own-out kernel estimator of E[Y|X]. This criterion can be used for
% bandwidth selection

% INPUTS
% h     : Bandwidth value at which prediction error is being evaluated
% Y     : N x 1 vector of dependent variable realizations
% X     : N x K matrix of independent variable realizations

% OUTPUTS
% EPE   : mean squared prediction error for leave-own-out kernel estimator
%         of the CEF

[N K] = size(X);                    % Dimensions of data
LeaveOwnOutYHAT = zeros(N,1);       % Preallocate leave-own-out YHAT vector

% Calculate leave-own-out estimate of CEF for each X(i)
K_h_evals = K_h(X,X,[h; h],[],KernelType);          % N x N kernel evalautions
num       = repmat(Y,1,N) .* K_h_evals;             % N x N "numerator" elements
den       = K_h_evals;                              % N x N "denominator" elements
alpha2    = sum(num) - diag(num)';                  % leave-own-out numerators
alpha1    = sum(den) - diag(den)';                  % leave-out-out denominators  
LeaveOwnOutYHAT = (alpha2 ./ alpha1)';              % leave-out-out CEF estimates

% Compute estimated mean squared prediction error
EPE = mean((Y - LeaveOwnOutYHAT).^2);


