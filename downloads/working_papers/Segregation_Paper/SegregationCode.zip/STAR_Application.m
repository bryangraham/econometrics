%------------------------------------------------------------------------%
%-"Measuring the average outcome and inequality effects of segregation  -%
%- in the presence of social spillovers" (Graham, Imbens & Ridder)      -%
%------------------------------------------------------------------------%

%------------------------------------------------------------------------%
%- BASE CODE FOR EMPIRICAL APPLICATION                                  -%
%------------------------------------------------------------------------%

load star_math.mat

Y = mathnorm;
T = female;
S = s_class;
R = [s_school enrollment classsize];
tau = (s_school>=0.35) .* (s_school<=0.65) .* (enrollment>=50) .* (enrollment<=150) ;
mean(tau)
G = class_id;
clear class_id classsize enrollment female mathnorm s_class s_school;

% Calculate ASF for girls and boys
KernelType = 0; % Use standard multivariate normal kernel
s = [0.30 0.325 0.35 0.375 0.4 0.425 0.45 0.475 0.5 0.525 0.55 0.575 0.6 0.625 0.65 0.675 0.70]';
h = [];
    
%-------------------------------------------------------------------------%
%- ASF for girls (high types)                                            -%
%-------------------------------------------------------------------------%

i = find(T==1);
N_H = length(i)
clear N_H;

% Choose bandwidth by LSCV (leave own group out)
h_grid      = [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2]';
J           = length(h_grid);
CV_Results  = [h_grid zeros(J,1)];
for j = 1:J    
    CV_Results(j,2) = LeaveGroupOutEPE(h_grid(j),Y(i),[S(i) R(i,:)],G(i),KernelType);
end
CV_Results = sortrows(CV_Results,2);
h = [CV_Results(1,1) CV_Results(1,1)]
clear h_grid J CV_Results;

% Estimate ASF
[m_H_bar, se_m_H_bar] = PartialMean(Y(i),S(i),s,R(i,:),tau(i),G(i),h,KernelType)
LB90_H = m_H_bar - 1.645*se_m_H_bar;
UB90_H = m_H_bar + 1.645*se_m_H_bar;
figure;
subplot(1,2,1)
plot(s, m_H_bar, 'k-', s, LB90_H, 'r--', s, UB90_H, 'r--');
clear i m_H_bar se_m_H_bar LB90_H UB90_H;

%-------------------------------------------------------------------------%
%- ASF for boys (low types)                                              -%
%-------------------------------------------------------------------------%

i = find(T==0);
N_L = length(i)
clear N_L;

% Choose bandwidth by LSCV (leave own group out)
h_grid      = [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2]';
J           = length(h_grid);
CV_Results  = [h_grid zeros(J,1)];
for j = 1:J
    CV_Results(j,2) = LeaveGroupOutEPE(h_grid(j),Y(i),[S(i) R(i,:)],G(i),KernelType);
end
CV_Results = sortrows(CV_Results,2);
h = [CV_Results(1,1) CV_Results(1,1)]
clear h_grid J CV_Results;

% Estimate ASF
[m_L_bar, se_m_L_bar] = PartialMean(Y(i),S(i),s,R(i,:),tau(i),G(i),h,KernelType)
LB90_L = m_L_bar - 1.645*se_m_L_bar;
UB90_L = m_L_bar + 1.645*se_m_L_bar;
subplot(1,2,2)
plot(s, m_L_bar, 'k-', s, LB90_L, 'r--', s, UB90_L, 'r--');
clear i h m_L_bar se_m_L_bar LB90_L UB90_L;

%-------------------------------------------------------------------------%
%- ASF for boys and girls combined                                       -%
%-------------------------------------------------------------------------%

% Choose bandwidth by LSCV (leave own group out)
h_grid      = [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2]';
J           = length(h_grid);
CV_Results  = [h_grid zeros(J,1)];
for j = 1:J
    CV_Results(j,2) = LeaveGroupOutEPE(h_grid(j),Y,[S R],G,KernelType);
end
CV_Results = sortrows(CV_Results,2);
h = [CV_Results(1,1) CV_Results(1,1)]

% Estimate ASF
[m_bar, se_m_bar] = PartialMean(Y,S,s,R,tau,G,h,KernelType)
LB90 = m_bar - 1.645*se_m_bar;
UB90 = m_bar + 1.645*se_m_bar;
figure
subplot(1,2,1)
plot(s, m_bar, 'k-', s, LB90, 'r--', s, UB90, 'r--');
subplot(1,2,2)
hist(S);

%-------------------------------------------------------------------------%
%- Calculate reallocation estimates                                      -%
%-------------------------------------------------------------------------%

KernelType = 0;        % Use standard multivariate normal kernel
h = [];                % Use `rule-of-thumb' bandwidth
h_grid      = [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2]';

UnderSmoothingFactor = 1;
[theta_hat] = LRE(Y,T,S,R,G,tau,h,h_grid,KernelType,UnderSmoothingFactor);

UnderSmoothingFactor = 5/6;
[theta_hat] = LRE(Y,T,S,R,G,tau,h,h_grid,KernelType,UnderSmoothingFactor);

UnderSmoothingFactor = 4/6;
[theta_hat] = LRE(Y,T,S,R,G,tau,h,h_grid,KernelType,UnderSmoothingFactor);

UnderSmoothingFactor = 3/6;
[theta_hat] = LRE(Y,T,S,R,G,tau,h,h_grid,KernelType,UnderSmoothingFactor);

