function [y_hat, y_gradient_hat] = KernelCEFAndGradient(Y,X,x,h,GRAD,KernelType)

% OVERVIEW
% This function estimates E[Y|X=x] and dE[Y|X=x]/dx using kernel methods.
% The kernel is the "radially symmetric" Epanechnikov kernel (Wand and Jones 
% 1995, p. 105) or a standard multivariate normal pdf. The bandwidth matrix 
% is assumed to take the form (h^2)S, where S is the sample covariance of X.

% INPUTS
% Y             : N x 1 vector of values for the dependent variable
% X             : N x K matrix of values for the independent variables
% x             : P x K matrix of values of X for which to estimate E[Y|X=x]
% h             : 2 X 1 vector of scalar bandwidth parameter for E[Y|X=x]
%               : and its derivative
% GRAD          : If GRAD = 1 then also calculate gradient-related objects    
% KernelType    : Radially symmetric kernal if 1 and standard multivariate normal kernel
%                 otherwise

% OUTPUTS
% y_hat             : P x 1 vector of fitted kernel estimates of the CEF
% y_gradient_hat    : P x K matrix of CEF partial gradients in the rows

[P K] = size(x);    % dimensions of data and evaluation grid
[N K] = size(X);

% STEP 1 : Estimate alpha2 = f(x)E[Y|X=x], alpha1 = f(x)
[K_h_evals, K_h_Derivative_evals] = K_h(X,x,h,GRAD,KernelType);
alpha2    = mean(repmat(Y,1,P) .* K_h_evals);               % 1 x P
alpha1    = mean(K_h_evals);                                % 1 x P

% STEP 2 : Estimate E[Y|X=x] (a P x 1 vector of fitted values)
y_hat     = (alpha2 ./ alpha1)';                            % P x 1

% STEP 3 : Estimate partial derivative of E[Y|X=x] w.r.t. x 
% (a P x K matrix of fitted values)
if GRAD == 1
    alpha1    = repmat(alpha1,1,K);
    alpha2    = repmat(alpha2,1,K);
    Dalpha2   = mean(repmat(Y,1,P*K) .* K_h_Derivative_evals);  % 1 x PK
    Dalpha1   = mean(K_h_Derivative_evals);                     % 1 x PK
    y_gradient_hat     = ((alpha1.^-1) .* (Dalpha2 - Dalpha1 .* (alpha2 ./ alpha1)))';
    y_gradient_hat     = reshape(y_gradient_hat,P,K);
else
    y_gradient_hat     = [];
end
        



