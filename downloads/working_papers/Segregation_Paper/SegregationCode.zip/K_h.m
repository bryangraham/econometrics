function [K_h_evals, K_h_Derivative_evals] = K_h(R,r,h,GRAD,KernelType)

% OVERVIEW
% This function calculates K_h(R-r) for each of the N realizations of the 
% K x 1 random variable R in the supplied dataset. This is done for each 
% of P points of evaluation given in r. K_h(x) = (1/h^K)k(x/h), where k(.) is
% a kernel function which integrates to one. This notation is as in Newey
% (1994, *Econometric Theory*) or Wand and Jones (1995) *Kernel Smoothing*. 
% The function also calculates the partial derivative of K_h(R-r) with 
% respect each of the K elements in r (at each of the P evaluation points).
% The kernel is either the "radially symmetric" Epanechnikov kernel (Wand and Jones 
% 1995, p. 105) or the standard multivariate normal density function. The bandwidth 
% matrix is assumed to take the form (h^2)S, where S is the sample covariance of X.

% INPUTS
% R             : N x K matrix of variables (each row is a realization of R')
% r             : P x K matrix of evaluation points (each row is an evaluation point)
% h             : 2 x 1 vector of scalar bandwidth parameters (measured on the scale of standard
%                 deviations of each component of R). h=(h1,h2)' with h1 used for
%                 the density estimate and h2 for the derivative estimate.
% GRAD          : If GRAD = 1 then also calculate gradient-related objects    
% KernelType    : Radially symmetric kernel if 1 and standard multivariate normal kernel
%                 otherwise

% OUTPUTs
% K_h_evals            : N x P matrix of K_h() evaluations for each of the P evaluation
%                        points and N observations.
% K_h_Derivative_evals : N x PK matrix of the derivatives of K_h(R-r) w.r.t.
%                        to each of the K elements of r.

[N K] = size(R);        % dimensions of data and evaluation grid
[P K] = size(r);

h1 = h(1);              % bandwidths for density and its derivative respectively
h2 = h(2);

% STEP 1: Standardize R to have an identity covariance matrix
SIGMA_RR  = cov(R);             % K x K sample covariance of R
C         = chol(SIGMA_RR);     % Cholesky decomposition of SIGMA_RR
dC        = det(C);             % determinant of C
R_std     = (C' \ R')';         % rotate data to have spherical covariance matrix
r_std     = (C' \ r')';             
clear R r;

% STEP 2: Calculate K_h_evals
% NOTE: K_h_evals will include a total of NP x K elements. We can use
% Kronecker products to calculate it without loops.
t   = repmat(R_std,P,1);        clear R_std;
t2  = reshape(r_std,P*K,1);     clear r_std;
t2  = repmat(t2',N,1);
t2  = reshape(t2,N*P,K);
t   = (t - t2)/h1;                                         % NP x K deviations of R_std from r_std
clear t2;
tt  = sum(t.^2,2);                                         % NP x 1 "(R - r)'iSIGMA_RR(R - r)/h1^2" for each of NP points of evaluation

if KernelType == 1
    % Use radially symmetric Epanechnikov kernel (Wand and Jones 1995, p. 105).
    v_d       = (2*pi^(K/2))/(K*gamma(K/2));    % volume of K-dimensional sphere
    K_h_evals = (1/h1^K)*(1/dC)*(1/2)*(1/v_d)*(K+2)*(1 - tt) .* (tt <= 1); 
else
    % Use standard multivariate normal kernel
    K_h_evals = (1/h1^K)*(1/dC)*((2*pi)^(K/2))*exp(-0.5*tt);    % normal product kernel
end

% STEP 3: Calculate K_h_Derivative_evals if requested
if GRAD == 1
    % Calculate partial derivatives of K_h w.r.t. to r
    % NOTE : rescaling to account for different bandwidth used for derivative
    if KernelType == 1
        % Use radially symmetric Epanechnikov kernel (Wand and Jones 1995, p. 105).
        K_h_Derivative_evals = ((1/h2^K)*(1/dC)*(1/v_d)*(K+2))*((h1/h2)*t / (h2*C')); % NP x K    
        K_h_Derivative_evals = K_h_Derivative_evals .* repmat((((h1/h2)^2)*tt <= 1),1,K); 
    else
        % Use standard multivariate normal kernel
        K_h_Derivative_evals = (1/h2^K)*(1/dC)*((2*pi)^(K/2))*((h1/h2)*t / (h2*C')); % NP x K    
        K_h_Derivative_evals = K_h_Derivative_evals .* repmat(exp(-0.5*((h1/h2)^2)*tt),1,K); 
    end
    
    % Reshape derivative matrix into N x PK matrix (i.e., K blocks of N x P matrices of partial derivatives)
    K_h_Derivative_evals = reshape(K_h_Derivative_evals,N,P*K);      
else
    K_h_Derivative_evals = [];
end

% Reshape K_h_evals into an N x P matrix of density evaluations
K_h_evals = reshape(K_h_evals,N,P);